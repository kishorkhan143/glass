/**
 * regular-glass.ts
 *
 * Standalone TypeScript module for the "Regular Glass" floating panel.
 * Copied from site/index.html (lines 1006-1010) and src/defaults.ts.
 *
 * Usage:
 *   import { initRegularGlass } from './regular-glass.ts';
 *   const instance = await initRegularGlass();
 */

import { LiquidGlass } from '../src/index.js';
import type { GlassConfig, LiquidGlassOptions } from '../src/index.js';

// ─── Regular Glass config ─────────────────────────────────────────────────────
// Copied exactly from site/index.html lines 1006–1010
const REGULAR_GLASS_CONFIG: Partial<GlassConfig> = {
	floating     : true,
	cornerRadius : 40,
	blurAmount   : 0,
};

// ─── DOM element IDs ──────────────────────────────────────────────────────────
const ROOT_ID  = 'hero-root';
const PANEL_ID = 'glass-fp1';

// ─── Main init function ───────────────────────────────────────────────────────
export async function initRegularGlass(): Promise<InstanceType<typeof LiquidGlass>> {
	const root = document.getElementById(ROOT_ID) as HTMLElement;
	if (!root) throw new Error(`#${ROOT_ID} not found in the DOM.`);

	const panel = document.getElementById(PANEL_ID) as HTMLElement;
	if (!panel) throw new Error(`#${PANEL_ID} not found in the DOM.`);

	// Apply the Regular Glass config via dataset (copied from site/index.html)
	panel.dataset.config = JSON.stringify(REGULAR_GLASS_CONFIG);

	const options: LiquidGlassOptions = {
		root,
		glassElements: document.querySelectorAll<HTMLElement>(`#${PANEL_ID}`),
	};

	const instance = await LiquidGlass.init(options);
	return instance;
}

// ─── Auto-init when this module is the entry point ───────────────────────────
initRegularGlass().catch(console.error);

